-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: sleepy_scholar1
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `course_id` int NOT NULL AUTO_INCREMENT,
  `course_name` varchar(100) DEFAULT NULL,
  `duration_years` int DEFAULT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,'BE Data Science',4);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fees`
--

DROP TABLE IF EXISTS `fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fees` (
  `fee_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int DEFAULT NULL,
  `semester_id` int DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `paid_amount` decimal(10,2) DEFAULT NULL,
  `due_amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  PRIMARY KEY (`fee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fees`
--

LOCK TABLES `fees` WRITE;
/*!40000 ALTER TABLE `fees` DISABLE KEYS */;
INSERT INTO `fees` VALUES (1,1,1,50000.00,50000.00,0.00,'Paid','2023-06-10'),(2,2,1,50000.00,30000.00,20000.00,'Partial','2023-06-12'),(3,3,1,50000.00,0.00,50000.00,'Pending',NULL),(4,4,1,50000.00,50000.00,0.00,'Paid','2023-06-11'),(5,5,1,50000.00,25000.00,25000.00,'Partial','2023-06-13'),(6,6,1,50000.00,50000.00,0.00,'Paid','2023-06-10'),(7,7,1,50000.00,0.00,50000.00,'Pending',NULL),(8,8,1,50000.00,40000.00,10000.00,'Partial','2023-06-14'),(9,9,1,50000.00,50000.00,0.00,'Paid','2023-06-15'),(10,10,1,50000.00,0.00,50000.00,'Pending',NULL),(11,11,1,50000.00,50000.00,0.00,'Paid','2023-06-10'),(12,12,1,50000.00,20000.00,30000.00,'Partial','2023-06-11'),(13,13,1,50000.00,0.00,50000.00,'Pending',NULL),(14,14,1,50000.00,50000.00,0.00,'Paid','2023-06-12'),(15,15,1,50000.00,30000.00,20000.00,'Partial','2023-06-13'),(16,16,1,50000.00,50000.00,0.00,'Paid','2023-06-14'),(17,17,1,50000.00,0.00,50000.00,'Pending',NULL),(18,18,1,50000.00,45000.00,5000.00,'Partial','2023-06-15'),(19,19,1,50000.00,50000.00,0.00,'Paid','2023-06-10'),(20,20,1,50000.00,0.00,50000.00,'Pending',NULL),(21,21,1,50000.00,50000.00,0.00,'Paid','2023-06-11'),(22,22,1,50000.00,20000.00,30000.00,'Partial','2023-06-12'),(23,23,1,50000.00,0.00,50000.00,'Pending',NULL),(24,24,1,50000.00,50000.00,0.00,'Paid','2023-06-13'),(25,25,1,50000.00,25000.00,25000.00,'Partial','2023-06-14'),(26,26,1,50000.00,50000.00,0.00,'Paid','2023-06-15'),(27,27,1,50000.00,0.00,50000.00,'Pending',NULL),(28,28,1,50000.00,40000.00,10000.00,'Partial','2023-06-10'),(29,29,1,50000.00,50000.00,0.00,'Paid','2023-06-11'),(30,30,1,50000.00,0.00,50000.00,'Pending',NULL),(31,31,1,50000.00,50000.00,0.00,'Paid','2023-06-12'),(32,32,1,50000.00,30000.00,20000.00,'Partial','2023-06-13'),(33,33,1,50000.00,0.00,50000.00,'Pending',NULL),(34,34,1,50000.00,50000.00,0.00,'Paid','2023-06-14'),(35,35,1,50000.00,25000.00,25000.00,'Partial','2023-06-15'),(36,36,1,50000.00,50000.00,0.00,'Paid','2023-06-10'),(37,37,1,50000.00,0.00,50000.00,'Pending',NULL),(38,38,1,50000.00,45000.00,5000.00,'Partial','2023-06-11'),(39,39,1,50000.00,50000.00,0.00,'Paid','2023-06-12'),(40,40,1,50000.00,0.00,50000.00,'Pending',NULL),(41,41,1,50000.00,50000.00,0.00,'Paid','2023-06-13'),(42,42,1,50000.00,20000.00,30000.00,'Partial','2023-06-14'),(43,43,1,50000.00,0.00,50000.00,'Pending',NULL),(44,44,1,50000.00,50000.00,0.00,'Paid','2023-06-15'),(45,45,1,50000.00,25000.00,25000.00,'Partial','2023-06-10'),(46,46,1,50000.00,50000.00,0.00,'Paid','2023-06-11'),(47,47,1,50000.00,0.00,50000.00,'Pending',NULL),(48,48,1,50000.00,40000.00,10000.00,'Partial','2023-06-12'),(49,49,1,50000.00,50000.00,0.00,'Paid','2023-06-13'),(50,50,1,50000.00,0.00,50000.00,'Pending',NULL);
/*!40000 ALTER TABLE `fees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marks`
--

DROP TABLE IF EXISTS `marks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marks` (
  `mark_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int DEFAULT NULL,
  `subject_id` int DEFAULT NULL,
  `semester_id` int DEFAULT NULL,
  `marks_obtained` int DEFAULT NULL,
  `max_marks` int DEFAULT NULL,
  `grade` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`mark_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marks`
--

LOCK TABLES `marks` WRITE;
/*!40000 ALTER TABLE `marks` DISABLE KEYS */;
INSERT INTO `marks` VALUES (1,1,1,1,85,100,'A'),(2,1,2,1,78,100,'B'),(3,2,1,1,65,100,'C'),(4,2,2,1,70,100,'B'),(5,3,1,1,50,100,'D'),(6,3,2,1,55,100,'D'),(7,4,1,1,90,100,'A'),(8,4,2,1,88,100,'A'),(9,5,1,1,72,100,'B'),(10,5,2,1,68,100,'C'),(11,6,1,1,80,100,'A'),(12,6,2,1,75,100,'B'),(13,7,1,1,45,100,'F'),(14,7,2,1,50,100,'D'),(15,8,1,1,67,100,'C'),(16,8,2,1,74,100,'B'),(17,9,1,1,88,100,'A'),(18,9,2,1,90,100,'A'),(19,10,1,1,40,100,'F'),(20,10,2,1,48,100,'F'),(21,11,1,1,82,100,'A'),(22,11,2,1,79,100,'B'),(23,12,1,1,60,100,'C'),(24,12,2,1,65,100,'C'),(25,13,1,1,55,100,'D'),(26,13,2,1,50,100,'D'),(27,14,1,1,92,100,'A'),(28,14,2,1,89,100,'A'),(29,15,1,1,70,100,'B'),(30,15,2,1,75,100,'B'),(31,16,1,1,85,100,'A'),(32,16,2,1,80,100,'A'),(33,17,1,1,48,100,'F'),(34,17,2,1,52,100,'D'),(35,18,1,1,78,100,'B'),(36,18,2,1,82,100,'A'),(37,19,1,1,88,100,'A'),(38,19,2,1,85,100,'A'),(39,20,1,1,42,100,'F'),(40,20,2,1,45,100,'F'),(41,21,1,1,90,100,'A'),(42,21,2,1,87,100,'A'),(43,22,1,1,65,100,'C'),(44,22,2,1,70,100,'B'),(45,23,1,1,50,100,'D'),(46,23,2,1,55,100,'D'),(47,24,1,1,88,100,'A'),(48,24,2,1,90,100,'A'),(49,25,1,1,72,100,'B'),(50,25,2,1,68,100,'C'),(51,26,1,1,80,100,'A'),(52,26,2,1,75,100,'B'),(53,27,1,1,45,100,'F'),(54,27,2,1,50,100,'D'),(55,28,1,1,67,100,'C'),(56,28,2,1,74,100,'B'),(57,29,1,1,88,100,'A'),(58,29,2,1,90,100,'A'),(59,30,1,1,40,100,'F'),(60,30,2,1,48,100,'F'),(61,31,1,1,82,100,'A'),(62,31,2,1,79,100,'B'),(63,32,1,1,60,100,'C'),(64,32,2,1,65,100,'C'),(65,33,1,1,55,100,'D'),(66,33,2,1,50,100,'D'),(67,34,1,1,92,100,'A'),(68,34,2,1,89,100,'A'),(69,35,1,1,70,100,'B'),(70,35,2,1,75,100,'B'),(71,36,1,1,85,100,'A'),(72,36,2,1,80,100,'A'),(73,37,1,1,48,100,'F'),(74,37,2,1,52,100,'D'),(75,38,1,1,78,100,'B'),(76,38,2,1,82,100,'A'),(77,39,1,1,88,100,'A'),(78,39,2,1,85,100,'A'),(79,40,1,1,42,100,'F'),(80,40,2,1,45,100,'F'),(81,41,1,1,90,100,'A'),(82,41,2,1,87,100,'A'),(83,42,1,1,65,100,'C'),(84,42,2,1,70,100,'B'),(85,43,1,1,50,100,'D'),(86,43,2,1,55,100,'D'),(87,44,1,1,88,100,'A'),(88,44,2,1,90,100,'A'),(89,45,1,1,72,100,'B'),(90,45,2,1,68,100,'C'),(91,46,1,1,80,100,'A'),(92,46,2,1,75,100,'B'),(93,47,1,1,45,100,'F'),(94,47,2,1,50,100,'D'),(95,48,1,1,67,100,'C'),(96,48,2,1,74,100,'B'),(97,49,1,1,88,100,'A'),(98,49,2,1,90,100,'A'),(99,50,1,1,40,100,'F'),(100,50,2,1,48,100,'F');
/*!40000 ALTER TABLE `marks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `progress`
--

DROP TABLE IF EXISTS `progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `progress` (
  `progress_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int DEFAULT NULL,
  `semester_id` int DEFAULT NULL,
  `attendance_percentage` decimal(5,2) DEFAULT NULL,
  `cgpa` decimal(4,2) DEFAULT NULL,
  `remarks` text,
  PRIMARY KEY (`progress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `progress`
--

LOCK TABLES `progress` WRITE;
/*!40000 ALTER TABLE `progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `semesters`
--

DROP TABLE IF EXISTS `semesters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `semesters` (
  `semester_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int DEFAULT NULL,
  `semester_number` int DEFAULT NULL,
  `year` int DEFAULT NULL,
  PRIMARY KEY (`semester_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `semesters`
--

LOCK TABLES `semesters` WRITE;
/*!40000 ALTER TABLE `semesters` DISABLE KEYS */;
/*!40000 ALTER TABLE `semesters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students1`
--

DROP TABLE IF EXISTS `students1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students1` (
  `student_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `address` text,
  `admission_date` date DEFAULT NULL,
  `course_id` int DEFAULT NULL,
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students1`
--

LOCK TABLES `students1` WRITE;
/*!40000 ALTER TABLE `students1` DISABLE KEYS */;
INSERT INTO `students1` VALUES (1,'Aarav','Sharma','aarav1@gmail.com','9000000001',NULL,NULL,NULL,'2023-06-01',1),(2,'Vivaan','Patel','vivaan2@gmail.com','9000000002',NULL,NULL,NULL,'2023-06-01',1),(3,'Aditya','Verma','aditya3@gmail.com','9000000003',NULL,NULL,NULL,'2023-06-01',1),(4,'Vihaan','Reddy','vihaan4@gmail.com','9000000004',NULL,NULL,NULL,'2023-06-01',1),(5,'Arjun','Mehta','arjun5@gmail.com','9000000005',NULL,NULL,NULL,'2023-06-01',1),(6,'Sai','Nair','sai6@gmail.com','9000000006',NULL,NULL,NULL,'2023-06-01',1),(7,'Krishna','Iyer','krishna7@gmail.com','9000000007',NULL,NULL,NULL,'2023-06-01',1),(8,'Ishaan','Gupta','ishaan8@gmail.com','9000000008',NULL,NULL,NULL,'2023-06-01',1),(9,'Rohan','Singh','rohan9@gmail.com','9000000009',NULL,NULL,NULL,'2023-06-01',1),(10,'Kabir','Yadav','kabir10@gmail.com','9000000010',NULL,NULL,NULL,'2023-06-01',1),(11,'Ananya','Shah','ananya11@gmail.com','9000000011',NULL,NULL,NULL,'2023-06-01',1),(12,'Diya','Joshi','diya12@gmail.com','9000000012',NULL,NULL,NULL,'2023-06-01',1),(13,'Aanya','Kulkarni','aanya13@gmail.com','9000000013',NULL,NULL,NULL,'2023-06-01',1),(14,'Myra','Kapoor','myra14@gmail.com','9000000014',NULL,NULL,NULL,'2023-06-01',1),(15,'Sara','Malhotra','sara15@gmail.com','9000000015',NULL,NULL,NULL,'2023-06-01',1),(16,'Riya','Chopra','riya16@gmail.com','9000000016',NULL,NULL,NULL,'2023-06-01',1),(17,'Ira','Bansal','ira17@gmail.com','9000000017',NULL,NULL,NULL,'2023-06-01',1),(18,'Kiara','Saxena','kiara18@gmail.com','9000000018',NULL,NULL,NULL,'2023-06-01',1),(19,'Meera','Agarwal','meera19@gmail.com','9000000019',NULL,NULL,NULL,'2023-06-01',1),(20,'Tara','Desai','tara20@gmail.com','9000000020',NULL,NULL,NULL,'2023-06-01',1),(21,'Aryan','Mishra','aryan21@gmail.com','9000000021',NULL,NULL,NULL,'2023-06-01',1),(22,'Dev','Pandey','dev22@gmail.com','9000000022',NULL,NULL,NULL,'2023-06-01',1),(23,'Karan','Dubey','karan23@gmail.com','9000000023',NULL,NULL,NULL,'2023-06-01',1),(24,'Manav','Tiwari','manav24@gmail.com','9000000024',NULL,NULL,NULL,'2023-06-01',1),(25,'Yash','Tripathi','yash25@gmail.com','9000000025',NULL,NULL,NULL,'2023-06-01',1),(26,'Om','Chaudhary','om26@gmail.com','9000000026',NULL,NULL,NULL,'2023-06-01',1),(27,'Shiv','Jain','shiv27@gmail.com','9000000027',NULL,NULL,NULL,'2023-06-01',1),(28,'Amit','Sinha','amit28@gmail.com','9000000028',NULL,NULL,NULL,'2023-06-01',1),(29,'Nikhil','Thakur','nikhil29@gmail.com','9000000029',NULL,NULL,NULL,'2023-06-01',1),(30,'Rahul','Rawat','rahul30@gmail.com','9000000030',NULL,NULL,NULL,'2023-06-01',1),(31,'Pooja','Shinde','pooja31@gmail.com','9000000031',NULL,NULL,NULL,'2023-06-01',1),(32,'Sneha','Patil','sneha32@gmail.com','9000000032',NULL,NULL,NULL,'2023-06-01',1),(33,'Neha','Kadam','neha33@gmail.com','9000000033',NULL,NULL,NULL,'2023-06-01',1),(34,'Swati','Jadhav','swati34@gmail.com','9000000034',NULL,NULL,NULL,'2023-06-01',1),(35,'Kavya','More','kavya35@gmail.com','9000000035',NULL,NULL,NULL,'2023-06-01',1),(36,'Nisha','Pawar','nisha36@gmail.com','9000000036',NULL,NULL,NULL,'2023-06-01',1),(37,'Aditi','Sawant','aditi37@gmail.com','9000000037',NULL,NULL,NULL,'2023-06-01',1),(38,'Sakshi','Chavan','sakshi38@gmail.com','9000000038',NULL,NULL,NULL,'2023-06-01',1),(39,'Priya','Gawli','priya39@gmail.com','9000000039',NULL,NULL,NULL,'2023-06-01',1),(40,'Komal','Gaikwad','komal40@gmail.com','9000000040',NULL,NULL,NULL,'2023-06-01',1),(41,'Harsh','Vyas','harsh41@gmail.com','9000000041',NULL,NULL,NULL,'2023-06-01',1),(42,'Deep','Solanki','deep42@gmail.com','9000000042',NULL,NULL,NULL,'2023-06-01',1),(43,'Rajat','Bisht','rajat43@gmail.com','9000000043',NULL,NULL,NULL,'2023-06-01',1),(44,'Ankit','Negi','ankit44@gmail.com','9000000044',NULL,NULL,NULL,'2023-06-01',1),(45,'Varun','Kohli','varun45@gmail.com','9000000045',NULL,NULL,NULL,'2023-06-01',1),(46,'Sahil','Arora','sahil46@gmail.com','9000000046',NULL,NULL,NULL,'2023-06-01',1),(47,'Mohit','Gulati','mohit47@gmail.com','9000000047',NULL,NULL,NULL,'2023-06-01',1),(48,'Rakesh','Sethi','rakesh48@gmail.com','9000000048',NULL,NULL,NULL,'2023-06-01',1),(49,'Tarun','Khanna','tarun49@gmail.com','9000000049',NULL,NULL,NULL,'2023-06-01',1),(50,'Gaurav','Bedi','gaurav50@gmail.com','9000000050',NULL,NULL,NULL,'2023-06-01',1);
/*!40000 ALTER TABLE `students1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subjects` (
  `subject_id` int NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(100) DEFAULT NULL,
  `course_id` int DEFAULT NULL,
  `semester` int DEFAULT NULL,
  PRIMARY KEY (`subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (1,'Statistics',1,1),(2,'Python Programming',1,1),(3,'Data Analysis',1,2),(4,'Machine Learning',1,2),(5,'Deep Learning',1,3),(6,'Big Data',1,3);
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-11 22:26:48
