const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

// Routes
const authRoutes = require("./auth");
app.use("/auth", authRoutes);

// Start server
app.listen(5000, () => {
    console.log("🚀 Server running on http://localhost:5000");
});