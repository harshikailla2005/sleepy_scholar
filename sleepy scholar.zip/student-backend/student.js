const express = require("express");
const router = express.Router();
const db = require("./db");

// ✅ GET all students
router.get("/", (req, res) => {
    db.query("SELECT * FROM students1", (err, result) => {
        if (err) return res.json(err);
        res.json(result);
    });
});

// ✅ GET single student
router.get("/:id", (req, res) => {
    db.query("SELECT * FROM students1 WHERE student_id = ?", 
    [req.params.id], (err, result) => {
        if (err) return res.json(err);
        res.json(result);
    });
});

// ✅ ADD student
router.post("/", (req, res) => {
    const { first_name, last_name, email, phone, admission_date, course_id } = req.body;

    const sql = `
        INSERT INTO students1 
        (first_name, last_name, email, phone, admission_date, course_id)
        VALUES (?, ?, ?, ?, ?, ?)
    `;

    db.query(sql, 
        [first_name, last_name, email, phone, admission_date, course_id],
        (err, result) => {
            if (err) return res.json(err);
            res.json({ message: "Student Added" });
        }
    );
});

// ✅ UPDATE student
router.put("/:id", (req, res) => {
    const { first_name, last_name, email, phone } = req.body;

    const sql = `
        UPDATE students1 
        SET first_name=?, last_name=?, email=?, phone=?
        WHERE student_id=?
    `;

    db.query(sql, 
        [first_name, last_name, email, phone, req.params.id],
        (err, result) => {
            if (err) return res.json(err);
            res.json({ message: "Updated Successfully" });
        }
    );
});

// ✅ DELETE student
router.delete("/:id", (req, res) => {
    db.query("DELETE FROM students1 WHERE student_id=?", 
    [req.params.id], (err, result) => {
        if (err) return res.json(err);
        res.json({ message: "Deleted Successfully" });
    });
});

module.exports = router;