const express = require ('express');
const router = express.Router();
module.exports = router;
const API = "http://localhost:5000/auth";

// 👁️ Toggle password
function togglePassword() {
    const pass = document.getElementById("password");
    pass.type = pass.type === "password" ? "text" : "password";
}

// 🔐 LOGIN FUNCTION
async function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    const res = await fetch(API + "/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ username, password })
    });

    const data = await res.json();

    if (data.success) {
        alert("Login Successful ✅");

        // Save user locally (optional)
        localStorage.setItem("user", JSON.stringify(data.user));

        // Redirect to dashboard
        window.location.href = "dashboard.html";
    } else {
        alert("❌ Invalid Username or Password");
    }
}
